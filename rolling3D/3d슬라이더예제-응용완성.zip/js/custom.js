$(document).ready(function(){
	
	var gap = 230;
	var op = 0.1;
	doSlider();
	
	$(".next").on("click",function(){
		$(".panel li").first().appendTo(".panel");	
		doSlider();
	});
	
	$(".prev").on("click",function(){
		$(".panel li").last().prependTo(".panel");		
		doSlider();
	});	
	
	function doSlider(){
		$(".panel li").eq(0).css({"z-index":"1"}).animate({"margin-left":-400 - (gap*2) ,"opacity":1 -(op*2)},500);
		$(".panel li").eq(1).css({"z-index":"2"}).animate({"margin-left":-400 - (gap*1),"opacity":1-(op*1)},500);
		$(".panel li").eq(2).css({"z-index":"3"}).animate({"margin-left":-400 - (gap*0), "opacity":1-(op*0)},500);
		$(".panel li").eq(3).css({"z-index":"2"}).animate({"margin-left":-400 + (gap*1),"opacity":1-(op*1)},500);
		$(".panel li").eq(4).css({"z-index":"1"}).animate({"margin-left":-400 + (gap*2), "opacity":1 -(op*2)},500);
	}
	
});










