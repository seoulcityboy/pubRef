$(document).ready(function(){
	
	doSlider();
	
	$(".next").on("click",function(){
		$(".panel li").eq(0).appendTo(".panel");	
		doSlider();
	});
	
	$(".prev").on("click",function(){
		$(".panel li").eq(2).prependTo(".panel");		
		doSlider();
	});	
	
	function doSlider(){
		$(".panel li").eq(0).css({"z-index":"1"}).animate({"margin-left":"-800px","opacity":"0.5"},500);
		$(".panel li").eq(1).css({"z-index":"2"}).animate({"margin-left":"-400px","opacity":"1"},500);
		$(".panel li").eq(2).css({"z-index":"1"}).animate({"margin-left":"0px", "opacity":"0.5"},500);
	}
	
});










